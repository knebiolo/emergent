# Session Report: RL Reward Function Redesign & Bug Fixes
**Date:** January 3, 2026  
**Focus:** Critical reward function pathology preventing effective RL training

---

## Critical Bug Discovered

**Symptom:** All fish moving due east in straight lines, ignoring schooling behaviors and environmental cues.

**Root Cause Analysis:**
1. **Reward function exploitation**: RL optimizer discovered that stationary tight ball maximizes cohesion (10.0 weight) without requiring upstream migration (0.5 weight)
2. **Schooling weight collapse**: Cohesion and alignment weights optimized to zero because they weren't necessary for high reward
3. **Eastward drift mechanism**: 
   - Initial heading = `np.zeros()` = 0 radians = due east
   - When behavioral forces sum to zero, `arbitrate()` falls back to previous heading
   - Fish maintain eastward heading until hitting boundary

---

## Solutions Implemented

### 1. Fatigue Penalty (Critical Energy Management)
**Location:** [rl_training.py](../rl_training.py#L620-L647)

```python
# Heavily penalize low battery states
fatigue_penalty = 0.0
if battery_history is not None:
    low_battery_threshold = 0.3  # Below 30% is critical
    for t in range(T):
        alive_t = alive_history[t]
        if np.sum(alive_t) == 0:
            continue
        
        battery_t = battery_history[t, alive_t]
        # Count agent-timesteps below threshold
        low_battery_count = np.sum(battery_t < low_battery_threshold)
        fatigue_penalty += low_battery_count
        
        # Extra penalty for completely depleted (battery = 0)
        depleted_count = np.sum(battery_t <= 0.01)
        fatigue_penalty += depleted_count * 2.0  # Double penalty
    
    fatigue_penalty /= T  # Average over timesteps
```

**Impact:**
- **-10.0 penalty per agent-timestep** below 30% battery
- **-20.0 extra penalty** for complete depletion
- Forces RL optimizer to learn energy-efficient migration strategies

### 2. Upstream Progress Weight Increase (10× Boost)
**Before:** `mean_upstream_progress * 0.5`  
**After:** `mean_upstream_progress * 5.0`

**Rationale:**
- Original weight (0.5) was negligible compared to cohesion (10.0)
- No incentive to migrate when stationary schooling scored higher
- New weight (5.0) makes migration half as important as cohesion - biologically realistic

### 3. Longitudinal Profile Requirement (No Fallbacks)
**Location:** [rl_training.py](../rl_training.py#L509-L532)

```python
if longitudinal_profile is None:
    raise ValueError("longitudinal_profile is required - cannot use Y-displacement fallback")

# Use shapely geometry to compute distance along river centerline
from shapely.geometry import Point

initial_point = Point(initial_pos[0], initial_pos[1])
final_point = Point(final_pos[0], final_pos[1])

# Get distance along river using shapely's project method
initial_river_dist = longitudinal_profile.project(initial_point)
final_river_dist = longitudinal_profile.project(final_point)

total_upstream = final_river_dist - initial_river_dist
```

**Impact:**
- Accurate upstream measurement in curved channels
- Fails loudly if longitudinal profile missing (FAIL LOUD pattern)
- Prevents silent use of incorrect Y-displacement metric

### 4. Zero-Force Validation (Early Detection)
**Location:** [behavior.py](../behavior.py#L2710-L2733)

```python
# Validate that RL training hasn't zeroed all behavioral forces
if test_weights is not None:
    migrating_mask = ~tired
    tired_mask = tired
    
    if np.any(migrating_mask):
        max_mig_force = np.max(vec_sum_mig_magnitudes[migrating_mask])
        if np.all(vec_sum_mig_magnitudes[migrating_mask] < 1.0):
            raise ValueError(
                f"All migrating forces < 1.0N! RL training may have zeroed weights.\n"
                f"Max force: {max_mig_force:.4f}N\n"
                f"Weights: {test_weights}"
            )
```

**Impact:**
- Catches weight collapse during training (before fish start drifting)
- Provides diagnostic info (max force, current weights)
- Prevents silent failures

### 5. Minimum Schooling Weight Penalties
**Already implemented:** [rl_training.py](../rl_training.py#L649-L670)

```python
# HARSH penalty if ANY schooling weight drops below threshold
min_threshold = 1000.0  # Minimum acceptable weight
if cohesion_w < min_threshold:
    min_schooling_weight_penalty -= 50.0  # Major penalty
if alignment_w < min_threshold:
    min_schooling_weight_penalty -= 50.0
if collision_w < min_threshold:
    min_schooling_weight_penalty -= 50.0
```

**Impact:**
- Prevents optimizer from zeroing critical schooling behaviors
- -50.0 penalty per missing schooling component
- Maintains biologically realistic fish behavior

---

## Updated Reward Function Structure

```python
reward = (
    mean_cohesion * 10.0 +                  # Group cohesion (stay together)
    (mean_alignment + 1.0) * 5.0 +          # Velocity alignment (move together)
    mean_separation * 5.0 +                 # Collision avoidance
    mean_upstream_progress * 5.0 +          # MIGRATION (10× increase from 0.5)
    energy_efficiency * 2.0 +               # Minimize energy waste
    mean_drafting_benefit * 20.0 +          # Hydrodynamic drafting
    agents_near_boundary * -5.0 +           # Avoid boundaries
    dead_count * -50.0 +                    # Mortality penalty
    accel_smoothness_penalty * -0.2 +       # Smooth swimming
    fatigue_penalty * -10.0 +               # LOW BATTERY PENALTY (NEW)
    min_schooling_weight_penalty +          # Prevent weight collapse
    weight_diversity_bonus                  # Encourage balanced weights
)
```

---

## Testing Checklist

Watch for these during RL training:

### ✅ Expected Behaviors
- [ ] Fish maintain schooling behaviors throughout training
- [ ] Cohesion & alignment weights stay > 1000.0
- [ ] Upstream progress increases over episodes
- [ ] Battery levels managed (stay above 30% most of the time)
- [ ] Fish follow river corridor (not straight lines)

### ❌ Failure Modes (Should NOT Occur)
- [ ] ~~Eastward drift~~ (would trigger zero-force validation)
- [ ] ~~Schooling collapse~~ (min weight penalties prevent this)
- [ ] ~~Battery exhaustion~~ (fatigue penalty prevents this)
- [ ] ~~Stationary tight balls~~ (upstream weight now significant)

### 📊 Diagnostic Outputs
New reward components in logs:
```
'fatigue_penalty': fatigue_penalty * -10.0,
'upstream_progress': mean_upstream_progress * 5.0,
'min_schooling_penalty': min_schooling_weight_penalty,
'weight_diversity_bonus': weight_diversity_bonus
```

---

## Files Modified

1. **[rl_training.py](../rl_training.py)**
   - Lines 424-434: Added `battery_history`, `longitudinal_profile` parameters
   - Lines 509-532: Longitudinal profile-based upstream calculation (required)
   - Lines 620-647: Fatigue penalty computation
   - Lines 689-691: Added fatigue term to reward calculation
   - Lines 706-708: Added fatigue_penalty to components dict
   - Line 802: Pass battery & profile to reward function

2. **[behavior.py](../behavior.py)**
   - Lines 1663-1670: Removed silent exception in `find_nearest_refuge` (FAIL LOUD)
   - Lines 2710-2733: Added zero-force validation with diagnostics

3. **[rl_training_viewer.py](../rl_training_viewer.py)**
   - Lines 110-115: Fixed scroll wheel interference
   - Line 375: Disabled matplotlib scroll events

---

## Next Steps

1. **Run RL training** with new reward function
2. **Monitor weight evolution** - ensure schooling weights stay healthy
3. **Validate fatigue management** - check battery levels in logs
4. **Measure upstream progress** - verify longitudinal distance calculations
5. **Tune weights if needed** - current values are first-pass estimates

---

## Technical Notes

### Why Longitudinal Profile is Required
- **Curved rivers**: Y-displacement fails in meandering channels
- **Biological accuracy**: Fish migrate along river corridors, not Euclidean paths
- **Training validity**: Incorrect metrics teach incorrect behaviors

### Why Fatigue Penalty is Critical
- **Energy budget realism**: Wild salmon carefully manage energy reserves
- **Migration success**: Battery depletion = failed migration
- **Behavioral emergence**: Forces learning of velocity optimization, drafting, refugia use

### Why Upstream Weight Matters
- **Migration imperative**: Fish must move upstream to spawn - it's the primary objective
- **Previous failure**: 0.5 weight was dominated by cohesion (10.0)
- **Balance**: 5.0 weight makes migration half as important as schooling - reflects biology

---

**Session Duration:** ~2 hours  
**Complexity:** High - fundamental reward redesign  
**Risk:** Medium - changes core training dynamics  
**Testing Required:** Extensive - monitor at least 50-100 episodes
