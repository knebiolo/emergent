# Session 2026-01-02

## Entry 2: PID Vibration Diagnostic System

**Metadata:**
- author: GitHub Copilot (Claude Sonnet 4.5)
- timestamp: 2026-01-02T12:30:00Z
- tags: pid, diagnostics, vibration, heading, behavioral-cues, movement

**Files changed:**
- `src/emergent/salmon_abm/movement.py` (lines 726-744) - Added PID diagnostic tracking
- `src/emergent/salmon_abm/simulation.py` (multiple locations):
  - Lines 217-219: Initialized PID diagnostic arrays
  - Lines 276-278: Added diagnostic keys to timeseries creation
  - Line 1207: Removed local `import logging` causing UnboundLocalError
  - Line 1374: Added diagnostic keys to tracked timeseries
- `scripts/diagnose_pid_vibration.py` (new file, 182 lines) - Analysis script
- `run_pid_diagnostic_test.py` (new file) - Quick test harness

**Summary:**
Implemented comprehensive PID diagnostic system to investigate fish "vibration" in turbulent flow. Added tracking for heading change rate, PID error magnitude, and PID adjustment magnitude. Created analysis script that generates statistics, plots, and recommendations. Ran 200-timestep test with 50 agents. **Key finding: Vibration is caused by rapid behavioral cue updates (2.075°/timestep mean heading change), NOT PID oscillation.** PID error is low (0.0069 m/s mean), suggesting PID is functioning correctly. Only 2.1% of timesteps show vibration events (>5°/timestep), but max heading change is 180° (complete reversal), indicating rare but extreme cue conflicts.

**Commands run:**
```powershell
# Run diagnostic test (50 agents, 200 timesteps)
python run_pid_diagnostic_test.py
# Output: outputs/pid_diagnostic_test/sim_pid_test.h5

# Analyze PID behavior
python scripts/diagnose_pid_vibration.py outputs/pid_diagnostic_test/sim_pid_test.h5
# Output: outputs/pid_diagnostic_test/pid_diagnostics.png
```

**Active Context:**
- **Root cause identified:** Behavioral cues (rheotaxis, collision, boundary, etc.) updating heading too rapidly
- **PID status:** Functioning correctly - low error, low adjustments
- **Current PID gains:** k_p=1.0, k_i=0.0, k_d=0.0 (no derivative damping)
- **Diagnostic metrics tracked:**
  - `heading_delta`: Radians/timestep heading change (wrapped to [-π, π])
  - `error_magnitude`: ||ideal_vel - predicted_vel|| in m/s
  - `pid_adjustment_magnitude`: ||PID correction|| in m/s

**Implementation Details:**

### PID Diagnostic Tracking (movement.py lines 726-744)

Added three diagnostic arrays computed after each PID update:

```python
# Track heading change (wrapped to [-pi, pi])
if not hasattr(self.simulation, 'prev_heading'):
    self.simulation.prev_heading = self.simulation.heading.copy()
    self.simulation.heading_delta = np.zeros(self.simulation.num_agents)
else:
    delta = self.simulation.heading - self.simulation.prev_heading
    delta = np.arctan2(np.sin(delta), np.cos(delta))  # wrap to [-pi, pi]
    self.simulation.heading_delta = delta
    self.simulation.prev_heading = self.simulation.heading.copy()

# Store error and adjustment magnitudes
self.simulation.error_magnitude = np.linalg.norm(error, axis=1)
self.simulation.pid_adjustment_magnitude = np.linalg.norm(pid_adjustment, axis=1)
```

### Diagnostic Analysis Results

**From test run (50 agents, 200 timesteps, 20s duration):**

| Metric | Mean | Median | Max | 95th %ile |
|--------|------|--------|-----|-----------|
| Heading Δ (deg/timestep) | 2.075 | 0.000 | 180.000 | 0.000 |
| PID Error (m/s) | 0.0069 | 0.0000 | 0.5998 | 0.0315 |
| PID Adjustment (m/s) | 0.0069 | 0.0000 | 0.5998 | 0.0315 |

**Vibration events:** 2.1% of timesteps (heading change >5°/timestep)

**Correlation:** 0.235 between |heading_delta| and error_magnitude (weak to moderate)

### Bug Fixes During Implementation

**UnboundLocalError in simulation.py:**
- Problem: Local `import logging` on line 1207 caused Python to treat `logging` as local variable
- When line 1385 tried to use `logging.getLogger()` before the import, UnboundLocalError occurred
- Solution: Removed local import (module-level import already present at line 13)

**Missing HDF5 datasets:**
- Problem: New diagnostic arrays weren't being written to HDF5
- Root cause: Datasets must be created during initialization, not on first write
- Solution: 
  1. Added diagnostic array initialization in `simulation.__init__()` (lines 217-219)
  2. Added keys to `timeseries_keys` tuple passed to `io.write_sim_initial()` (line 276-278)
  3. Added keys to tracked datasets in `timestep()` (line 1374)

**Validation:**
- Created `run_pid_diagnostic_test.py` to run minimal 50-agent, 200-timestep simulation
- Script uses existing Nuyakuk environment data from `data/salmon_abm/`
- Diagnostic script successfully loaded all three new datasets from HDF5
- Generated 4-panel diagnostic plot with time series, distributions, and correlations

**Blockers:**
None - diagnostic system fully operational.

**Next steps:**

**BEFORE adding derivative damping (k_d), investigate behavioral cue updates:**

1. **Check heading update logic in behavior.arbitrate():**
   - How are cues weighted and combined?
   - Are there sudden switches between dominant cues?
   - Is there a dead-band or hysteresis to prevent oscillation?

2. **Examine specific cues that might cause flipping:**
   - Collision cue: Does inverse square law cause rapid reversals at close range?
   - Boundary cue: Are fish bouncing between repulsive zones?
   - Rheotaxis vs other cues: Conflicts in turbulent zones?

3. **Potential behavioral fixes (non-PID):**
   - Add heading rate limiter (e.g., max 10°/timestep)
   - Implement temporal smoothing (moving average of cue outputs)
   - Add hysteresis bands to prevent rapid cue switching
   - Weight cues by temporal stability (penalize rapidly changing cues)

4. **If behavioral fixes insufficient, then PID tuning:**
   - Add derivative term: k_d = 0.1 to 0.5 for damping
   - Implement error filtering (exponential moving average)
   - Consider position-dependent gains (lower k_p in turbulent zones)

**Notes:**
- Median heading_delta = 0° suggests most fish have stable headings
- Max = 180° indicates complete reversals (rare but present)
- Low PID error (0.0069 m/s) confirms PID is not the problem
- 95th percentile heading_delta = 0° means 95% of updates are stable
- The 2.1% vibration events are likely the visible "vibration" user observed

**Diagnostic plot contents:**
1. **Top-left:** Heading change rate time series (first 10 agents)
2. **Top-right:** PID error magnitude time series (first 10 agents)
3. **Bottom-left:** Heading change distribution (log scale)
4. **Bottom-right:** Scatter plot - heading change vs error magnitude

**What I wished I was told:**
- HDF5 timeseries datasets must be created before first write (can't be created on-demand)
- Local imports shadow module-level imports for entire function scope in Python
- The `io.write_sim_initial()` accepts `timeseries_keys` parameter for custom datasets
