Metadata:
- author: AI pair-programmer
- timestamp: 2025-12-23T00:00:00Z
- tags: nuyakuk, simulation, viewer, runbook

Files changed:
- src/emergent/salmon_abm/realtime_viewer.py (fixed indentation, improved CLI clarity)

Summary:
- The workspace contains a working in-package realtime viewer at `src/emergent/salmon_abm/realtime_viewer.py` which supports file playback and live TCP streaming. I fixed an IndentationError, removed excessive nested try/excepts, and confirmed the dev stream server (`tools/dev_stream_server.py`) can stream frames that the viewer receives.
- All simulation data and Nuyakuk configuration are available under the folder `data/salmon_abm`.
- The user wants to start a simulation using the Nuyakuk configuration and stream agent positions into the viewer on localhost:9001.

Commands run (examples used during debugging):
- python tools/dev_stream_server.py --host 127.0.0.1 --port 9001 --agents 1000 --fps 50
- python -m emergent.salmon_abm.realtime_viewer --live --host 127.0.0.1 --port 9001 --use-gl --force-vbo --debug

Blockers:
- None currently blocking. If OpenGL VBOs are desired, ensure `PyOpenGL` is installed in the Python environment.

Next steps (what we want the next AI to do):
1. Locate the Nuyakuk configuration and runtime command(s) in `data/salmon_abm` and provide an exact run command to start the simulation and stream agent positions to 127.0.0.1:9001.
2. If Nuyakuk does not natively stream, implement a minimal adapter `tools/nuyakuk_stream_adapter.py` which reads simulation output and streams frames in the viewer's expected formats (either raw 'R' header + 4-byte length + float32 payload, or length-prefixed `.npy`). Include usage instructions.
3. Run the simulation (or the adapter) and confirm the viewer shows agents. Report whether the OpenGL VBO path was used (from `viewer_debug.log`) and any runtime errors.

Prompt for the next AI (explicit):
- You are given a workspace with simulation data under `data/salmon_abm` and a realtime viewer at `src/emergent/salmon_abm/realtime_viewer.py`.
- Task:
  1. Inspect the `data/salmon_abm` folder for the Nuyakuk configuration and identify how to run the Nuyakuk simulation (provide the exact shell command). If necessary, identify environment setup steps like required Python packages.
  2. If the Nuyakuk binary or script supports TCP streaming, configure it to stream agent positions to 127.0.0.1:9001 and start it. If it doesn't, implement `tools/nuyakuk_stream_adapter.py` that reads the simulation's output files and streams frames in the viewer-compatible binary or `.npy` format.
  3. Launch `tools/dev_stream_server.py` as a fallback if direct streaming isn't possible, and use the adapter to inject frames.
  4. Launch the viewer with `--live --host 127.0.0.1 --port 9001 --use-gl --force-vbo --debug` and confirm frames are displayed. Check `viewer_debug.log` to determine whether raw VBO path was selected.
  5. Produce a short report with commands used, any new scripts added, and a troubleshooting checklist for common errors (missing PyOpenGL, connection refused, payload size mismatch).

Acceptance criteria:
- The next AI provides exact commands to start the Nuyakuk simulation or adapter to stream to the viewer, or commits `tools/nuyakuk_stream_adapter.py` with usage instructions and a quick verification run.

Notes for implementer:
- The viewer accepts `--live` as a flag and `--host`/`--port` separately; do not assume a single `tcp://host:port` argument.
- The raw protocol expected by the viewer supports two formats:
  - Raw: ASCII header 'R' followed by 4-byte big-endian uint32 length and then float32 array of shape (N*2,) (x,y interleaved or contiguous). The viewer will reshape to (-1, 2).
  - Numpy: length-prefixed `.npy` file bytes (4-byte big-endian length then .npy bytes). Viewer will np.load from buffer when `b"\x93NUMPY"` detected.

End of prompt.
